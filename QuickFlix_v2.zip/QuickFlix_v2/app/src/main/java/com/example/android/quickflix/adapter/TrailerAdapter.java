package com.example.android.quickflix.adapter;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.android.quickflix.R;
import com.example.android.quickflix.model.Trailers;

import java.util.List;

/**
 * Created by brockrice on 11/12/17.
 * This adapter will be used when the trailer button is clicked in order to
 * open a new activity to play the trialer
 */

public class TrailerAdapter extends RecyclerView.Adapter<TrailerAdapter.TrailerViewHolder> {

    private final List<Trailers> trailer;
    private final Context context;


    public TrailerAdapter(Context context, List<Trailers> trailer) {
        this.trailer = trailer;
        this.context = context;

    }

    @Override
    public TrailerViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.movie_trailer, parent, false);
        return new TrailerViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final TrailerAdapter.TrailerViewHolder trailerViewHolder, int position) {
        trailerViewHolder.title.setText(trailer.get(position).getName());

    }

    @Override
    public int getItemCount() {
        return trailer.size();
    }


    public class TrailerViewHolder extends RecyclerView.ViewHolder {
        public final TextView title;
        public final ImageView trailerPlayImage;


        public TrailerViewHolder(View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.tv_trailer_title);
            trailerPlayImage = itemView.findViewById(R.id.iv_trailer_play_image);

            itemView.setOnClickListener(new View.OnClickListener() {

                /**
                 * After play icon is clicked, set a Trailer object named clickedTrailerItem to the
                 *postion of the clicked trailer. Pass extras into the intend and get the position
                 * of each field in order to pass the intent.
                 */

                @Override
                public void onClick(View view) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        Trailers clickedTrailerItem = trailer.get(position);
                        String trailerId = trailer.get(position).getKey();

                        Intent appIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:" + trailerId));
                        appIntent.putExtra("VIDEO_ID", trailerId);
                        Intent webIntent = new Intent(Intent.ACTION_VIEW,
                                Uri.parse("http://www.youtube.com/watch?v=" + trailerId));
                        try {
                      /* (Intent.FLAG_ACTIVITY_NEW_TASK) is required in order to
                     * make sure Android does not try to launch this Activity within the current
                     * task. A new task will be created.
                     */
                            appIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            context.startActivity(appIntent);

                        } catch (ActivityNotFoundException ex) {
                            webIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            context.startActivity(webIntent);
                        }

                        Toast.makeText(view.getContext(), clickedTrailerItem.getKey(), Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
    }

}
