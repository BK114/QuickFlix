package com.example.android.quickflix.model;

import com.google.gson.annotations.SerializedName;

/**
 * Created by brockrice on 11/13/17.
 */

public class Reviews {


    @SerializedName("author")
    private final String author;
    @SerializedName("content")
    private String content;



    public Reviews(String author, String content) {

        this.author = author;
        this.content = content;
    }

    public String getAuthor() {
        return author;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}