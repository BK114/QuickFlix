package com.example.android.quickflix.Data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.android.quickflix.model.Movies;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by brockrice on 11/14/17.
 */

public class FavoritesDBHelper extends SQLiteOpenHelper {

    private static final String LOG_TAG = FavoritesDBHelper.class.getSimpleName();

    //name and version
    private static final String DATABASE_NAME = "favoriteMovies.db";
    private static final int DATABASE_VERSION = 3;

    public FavoritesDBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);

    }


    //create the database to specify what table will look like by overriding the onCreate method
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        final String SQL_CREATE_MOVIE_TABLE = "CREATE TABLE " +
                FavoritesContract.FavoritesEntry.TABLE_FAVORITES + "(" +
                FavoritesContract.FavoritesEntry._ID +
                " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                FavoritesContract.FavoritesEntry.COLUMN_MOVIE_ID + " INTEGER NOT NULL, " +
                FavoritesContract.FavoritesEntry.COLUMN_TITLE + " TEXT NOT NULL, " +
                FavoritesContract.FavoritesEntry.COLUMN_RELEASE_DATE + " TEXT, " +
                FavoritesContract.FavoritesEntry.COLUMN_USER_RATING + " REAL, " +
                FavoritesContract.FavoritesEntry.COLUMN_POSTER_PATH + " TEXT, " +
                FavoritesContract.FavoritesEntry.COLUMN_OVERVIEW + " TEXT, " +
                FavoritesContract.FavoritesEntry.COLUMN_AUTHOR + " TEXT, " +
                FavoritesContract.FavoritesEntry.COLUMN_CONTENT + " TEXT, " +

          /*
                 * To ensure this table can only contain one weather entry per date, we declare
                 * the date column to be unique. We also specify "ON CONFLICT REPLACE". This tells
                 * SQLite that if we have a weather entry for a certain date and we attempt to
                 * insert another weather entry with that date, we replace the old weather entry.
                 */
                " UNIQUE (" + FavoritesContract.FavoritesEntry.COLUMN_MOVIE_ID + ") ON CONFLICT REPLACE);";

        Log.w(LOG_TAG, "Log - Inserted: " + sqLiteDatabase);
        sqLiteDatabase.execSQL(SQL_CREATE_MOVIE_TABLE);
    }


    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
        Log.w(LOG_TAG, "Updating Database from version " + oldVersion + " to " +
                newVersion + ". OLD DATA WILL BE DESTROYED");
        //DROP the table
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + FavoritesContract.FavoritesEntry.TABLE_FAVORITES);

        sqLiteDatabase.execSQL("DELETE FROM SQLITE_SEQUENCE WHERE NAME = '" +
                FavoritesContract.FavoritesEntry.TABLE_FAVORITES + "'");
        //re-create the database
        onCreate(sqLiteDatabase);
    }

    public void addFavorites(Movies movies) {

        SQLiteDatabase sqLiteDatabase = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(FavoritesContract.FavoritesEntry.COLUMN_MOVIE_ID, movies.getMovieId());
        values.put(FavoritesContract.FavoritesEntry.COLUMN_TITLE, movies.getOriginalTitle());
        values.put(FavoritesContract.FavoritesEntry.COLUMN_RELEASE_DATE, movies.getReleaseDate());
        values.put(FavoritesContract.FavoritesEntry.COLUMN_USER_RATING, movies.getVoteAverage());
        values.put(FavoritesContract.FavoritesEntry.COLUMN_POSTER_PATH, movies.getPosterPath());
        values.put(FavoritesContract.FavoritesEntry.COLUMN_OVERVIEW, movies.getOverview());
        values.put(FavoritesContract.FavoritesEntry.COLUMN_AUTHOR, movies.getAuthor());
        values.put(FavoritesContract.FavoritesEntry.COLUMN_CONTENT, movies.getContent());
        Log.d(LOG_TAG, "addFavorites: Adding " + movies + " to " + FavoritesContract.FavoritesEntry.TABLE_FAVORITES);

        long result = sqLiteDatabase.insert(FavoritesContract.FavoritesEntry.TABLE_FAVORITES, null, values);
        sqLiteDatabase.close();
        if (result == -1) {
        } else {
        }
    }

    public void deleteFavorite(int id) {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        sqLiteDatabase.delete(FavoritesContract.FavoritesEntry.TABLE_FAVORITES, FavoritesContract.FavoritesEntry.COLUMN_MOVIE_ID + "=" + id, null);
    }

    public List<Movies> getAllFavorites() {
        String[] columns = {
                FavoritesContract.FavoritesEntry._ID,
                FavoritesContract.FavoritesEntry.COLUMN_MOVIE_ID,
                FavoritesContract.FavoritesEntry.COLUMN_TITLE,
                FavoritesContract.FavoritesEntry.COLUMN_RELEASE_DATE,
                FavoritesContract.FavoritesEntry.COLUMN_USER_RATING,
                FavoritesContract.FavoritesEntry.COLUMN_POSTER_PATH,
                FavoritesContract.FavoritesEntry.COLUMN_OVERVIEW,
                FavoritesContract.FavoritesEntry.COLUMN_AUTHOR,
                FavoritesContract.FavoritesEntry.COLUMN_CONTENT
        };
        String sortOrder =
                FavoritesContract.FavoritesEntry.COLUMN_TITLE + " ASC";

        List<Movies> favoritesList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(FavoritesContract.FavoritesEntry.TABLE_FAVORITES,
                columns,
                null,
                null,
                null,
                null,
                sortOrder);
        if (cursor != null) {
            cursor.moveToFirst();

            do {
                Movies movies = new Movies();
                movies.setMovieId(Integer.parseInt(cursor.getString(cursor.getColumnIndex(FavoritesContract.FavoritesEntry.COLUMN_MOVIE_ID))));
                movies.setOriginalTitle(cursor.getString(cursor.getColumnIndex(FavoritesContract.FavoritesEntry.COLUMN_TITLE)));
                movies.setReleaseDate(cursor.getString(cursor.getColumnIndex(FavoritesContract.FavoritesEntry.COLUMN_RELEASE_DATE)));
                movies.setVoteAverage(Double.parseDouble(cursor.getString(cursor.getColumnIndex(FavoritesContract.FavoritesEntry.COLUMN_USER_RATING))));
                movies.setPosterPath(cursor.getString(cursor.getColumnIndex(FavoritesContract.FavoritesEntry.COLUMN_POSTER_PATH)));
                movies.setOverview(cursor.getString(cursor.getColumnIndex(FavoritesContract.FavoritesEntry.COLUMN_OVERVIEW)));
                movies.setAuthor(cursor.getString(cursor.getColumnIndex(FavoritesContract.FavoritesEntry.COLUMN_AUTHOR)));
                movies.setContent(cursor.getString(cursor.getColumnIndex(FavoritesContract.FavoritesEntry.COLUMN_CONTENT)));

                favoritesList.add(movies);
            }
            while (cursor.moveToNext());
        }
        assert cursor != null;
        cursor.close();
        db.close();

        return favoritesList;
    }
}