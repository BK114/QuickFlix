package com.example.android.quickflix.activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.android.quickflix.Data.FavoritesDBHelper;
import com.example.android.quickflix.R;
import com.example.android.quickflix.adapter.ReviewAdapter;
import com.example.android.quickflix.adapter.TrailerAdapter;
import com.example.android.quickflix.api.ApiInterfaceService;
import com.example.android.quickflix.api.RetrofitClient;
import com.example.android.quickflix.model.Movies;
import com.example.android.quickflix.model.Reviews;
import com.example.android.quickflix.model.ReviewsResponse;
import com.example.android.quickflix.model.TrailerResponse;
import com.example.android.quickflix.model.Trailers;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.IllegalFormatException;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MovieDetailActivity extends AppCompatActivity {

    private final static String LOG_TAG = MovieDetailActivity.class.getSimpleName();
    private final String API_KEY = "Your_API_KEY_HERE";
    private final AppCompatActivity activity = MovieDetailActivity.this;
    private ImageButton addFavoriteButton;
    private ImageButton removeFavoriteButton;

    private int movie_id;
    private String movieImage;
    private String movieTitle;
    private String dateReleased;
    private String synopsis;
    private String voterRating;
    private String author;
    private String content;

    private ProgressDialog progressDialog;
    private RecyclerView recyclerView1, recyclerView2;
    private FavoritesDBHelper favoritesDBHelper;
    private Movies favorites;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);

            progressDialog = new ProgressDialog(this);
            progressDialog.setMessage("Loading...");
            progressDialog.setCancelable(false);
            progressDialog.show();

            ImageView posterImage = findViewById(R.id.detail_movie_image);
            TextView title = findViewById(R.id.detail_movie_title);
            TextView releaseDate = findViewById(R.id.detail_release_date);
            TextView overview = findViewById(R.id.detail_overview);
            TextView rating = findViewById(R.id.detail_rating);

            //find id of favorites button and remove button
            addFavoriteButton = findViewById(R.id.favorite_button);
            removeFavoriteButton = findViewById(R.id.remove_favorite_button);
            removeFavoriteButton.setVisibility(View.GONE);
            Intent intentFromInitiator = getIntent();

            if (intentFromInitiator.hasExtra("movie")) {

                Movies movies = getIntent().getParcelableExtra("movie");

                movie_id = movies.getMovieId();
                movieImage = movies.getPosterPath();
                synopsis = movies.getOverview();
                dateReleased = movies.getReleaseDate();
                movieTitle = movies.getOriginalTitle();
                voterRating = Double.toString(movies.getVoteAverage());
                content = movies.getContent();
                author = movies.getAuthor();


                String IMAGE_URL_BASE_PATH = "http://image.tmdb.org/t/p/w185/";
                String image_url = IMAGE_URL_BASE_PATH + movieImage;
                Picasso.with(this)
                        .load(image_url)
                        .placeholder(R.drawable.andiron)
                        .error(R.drawable.popcorn)
                        .into(posterImage);

                title.setText(movieTitle);
                releaseDate.setText(dateReleased);
                overview.setText(synopsis);
                rating.setText(voterRating);

            } else {
                Toast.makeText(this, "No API Data", Toast.LENGTH_SHORT).show();
            }
        }

        addFavoriteButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                new saveFavorite().execute();
                addFavoriteButton.setVisibility(View.GONE);
                removeFavoriteButton.setVisibility(View.VISIBLE);
                // Log.v(LOG_TAG, "favorites data: " + favoritesDBHelper.toString());
                Snackbar.make(v, "Added to Favorites",
                        Snackbar.LENGTH_SHORT).show();
            }

        });

        removeFavoriteButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                try {
                    int movie_id = getIntent().getExtras().getInt("id");
                    removeFavoriteButton.setVisibility(View.GONE);
                    addFavoriteButton.setVisibility(View.VISIBLE);
                    favoritesDBHelper = new FavoritesDBHelper(MovieDetailActivity.this);
                    favoritesDBHelper.deleteFavorite(movie_id);
                    Snackbar.make(v, "Removed to Favorites",
                            Snackbar.LENGTH_SHORT).show();
                } catch (NullPointerException e) {
                    Toast.makeText(getApplicationContext(), "Oops something went wrong", Toast.LENGTH_SHORT).show();
                    Log.d(LOG_TAG, "onClick: " + getApplicationContext());
                }
            }
        });
        initializeTrailersViews();
        initializeReviewViews();

    }

    private void initializeTrailersViews() {

        List<Trailers> trailersList = new ArrayList<>();
        TrailerAdapter trailerAdapter = new TrailerAdapter(this, trailersList);

        recyclerView1 = findViewById(R.id.recycler_view_trailers);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView1.setLayoutManager(mLayoutManager);
        recyclerView1.setAdapter(trailerAdapter);
        trailerAdapter.notifyDataSetChanged();
        connectGetTrailers();
    }

    //Connect and get trailers
    private void connectGetTrailers() throws IllegalFormatException {

        try {
            int movie_id = getIntent().getExtras().getInt("id");
            if (API_KEY.isEmpty()) {
                Toast.makeText(getApplicationContext(), "Please Obtain an API Key", Toast.LENGTH_SHORT).show();
                return;
            }
            // Create an instance of ApiInterfaceService
            ApiInterfaceService trailerApiService = RetrofitClient.getRetrofit().create(ApiInterfaceService.class);
            Call<TrailerResponse> call = trailerApiService.getMovieTrailer(movie_id, API_KEY);
            call.enqueue(new Callback<TrailerResponse>() {

                /*
                 * get a response from Retrofit and create a new TrailerAdapter object that takes
                 * in movies and context. set adapter to the recycelerView with passed parameters
                 * set the title of the results to match the searched content.
                 */
                @Override
                public void onResponse(Call<TrailerResponse> call, Response<TrailerResponse> response) {

                    List<Trailers> trailers = response.body().getResults();
                    recyclerView1.setAdapter(new TrailerAdapter(getApplicationContext(), trailers));
                    recyclerView1.smoothScrollToPosition(0);
                    progressDialog.dismiss();
                }

                /*
                 * pass a toast to let the user know to check the device connectivity.
                 */
                @Override
                public void onFailure(Call<TrailerResponse> call, Throwable throwable) {
                    Log.d(LOG_TAG, throwable.toString());
                    Toast.makeText(MovieDetailActivity.this, "Please check your connection...", Toast.LENGTH_LONG).show();
                    progressDialog.dismiss();
                }
            });
        } catch (NullPointerException e) {
            Log.d("Error ", e.getMessage());
            e.printStackTrace();
            setContentView(R.layout.activity_main);
            Toast.makeText(getApplicationContext(), "Please Obtain an API KEY", Toast.LENGTH_SHORT).show();
        }
    }

    private void initializeReviewViews() {

        List<Reviews> reviewsList = new ArrayList<>();
        ReviewAdapter reviewAdapter = new ReviewAdapter(this, reviewsList);

        recyclerView2 = findViewById(R.id.recycler_view_reviews);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView2.setLayoutManager(mLayoutManager);
        recyclerView2.setAdapter(reviewAdapter);
        reviewAdapter.notifyDataSetChanged();
        connectGetReviews();
    }


    //Connect and get Most Popular Movies
    private void connectGetReviews() throws IllegalFormatException {

        try {
            int movie_id = getIntent().getExtras().getInt("id");
            if (API_KEY.isEmpty()) {
                Toast.makeText(getApplicationContext(), "Please Obtain an API Key", Toast.LENGTH_SHORT).show();
                return;
            }
            // Create an instance of ApiInterfaceService
            ApiInterfaceService reviewsApiService = RetrofitClient.getRetrofit().create(ApiInterfaceService.class);
            Call<ReviewsResponse> call = reviewsApiService.getMovieReviews(movie_id, API_KEY);
            call.enqueue(new Callback<ReviewsResponse>() {

                /*
                 * get a response from Retrofit and create a new ReviewAdapter object that takes
                 * in movies and context. set adapter to the recycelerView with passed parameters
                 * set the title of the results to match the searched content.
                 */
                @Override
                public void onResponse(Call<ReviewsResponse> call, Response<ReviewsResponse> response) {

                    List<Reviews> reviews = response.body().getResults();
                    recyclerView2.setAdapter(new ReviewAdapter(getApplicationContext(), reviews));
                    recyclerView2.smoothScrollToPosition(0);
                    progressDialog.dismiss();

                }

                /*
                 * pass a toast to let the user know to check the device connectivity.
                 */
                @Override
                public void onFailure(Call<ReviewsResponse> call, Throwable throwable) {
                    Log.d(LOG_TAG, throwable.toString());
                    Toast.makeText(getApplicationContext(), "Please check your connection...", Toast.LENGTH_LONG).show();
                    progressDialog.dismiss();
                }
            });
        } catch (NullPointerException e) {
            Log.d("Error ", e.getMessage());
            e.printStackTrace();
            setContentView(R.layout.activity_main);
            Toast.makeText(getApplicationContext(), "Please Obtain an API KEY", Toast.LENGTH_SHORT).show();
        }
    }


    public class saveFavorite extends AsyncTask<Void, Void, Void> {


        @Override
        protected Void doInBackground(Void... voids) {
            favoritesDBHelper = new FavoritesDBHelper(activity);
            favorites = new Movies();

            favorites.setMovieId(movie_id);
            favorites.setPosterPath(movieImage);
            favorites.setOriginalTitle(movieTitle);
            favorites.setReleaseDate(dateReleased);
            favorites.setOverview(synopsis);
            favorites.setVoteAverage(Double.parseDouble(voterRating));
            favorites.setAuthor(author);
            favorites.setContent(content);
            favoritesDBHelper.addFavorites(favorites);


            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            Log.v(LOG_TAG, "favorites logged: " + favorites.toString());
            favoritesDBHelper.close();
        }

    }
}
