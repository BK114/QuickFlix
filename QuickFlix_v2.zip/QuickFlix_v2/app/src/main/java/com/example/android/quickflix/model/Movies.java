package com.example.android.quickflix.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;

/**
 * Created by brockrice on 8/4/17. Create the Movie Object and serialize the required
 * fields
 */


public class Movies implements Parcelable {
    /*
     * Retrieve data from JSON returned by THe Movie Database
     * Ensure field names are the same as those in The Movie Database
     * we can use our own names within program.
     * Serialize each JSON parameter and match with Movies variables
     */
    @SerializedName("poster_path")
    private String posterPath;
    @SerializedName("overview")
    private String overview;
    @SerializedName("release_date")
    private String releaseDate;
    @SerializedName("original_title")
    private String originalTitle;
    @SerializedName("vote_average")
    private Double voteAverage;
    @SerializedName("id")
    private int movieId;
    @SerializedName("content")
    private String content;
    @SerializedName("author")
    private String author;



    public Movies(String posterPath, String overview, String releaseDate,
                  String originalTitle, Double voteAverage, Integer movieId, String author, String content) {
        this.posterPath = posterPath;
        this.overview = overview;
        this.releaseDate = releaseDate;
        this.originalTitle = originalTitle;
        this.voteAverage = voteAverage;
        this.movieId = movieId;
        this.author = author;
        this.content = content;

    }
    public Movies(){

    }


    public String getPosterPath() {
        return posterPath;
    }

    public String getOverview() {
        return overview;
    }

    public String getReleaseDate() {
        return releaseDate;
    }

    public String getOriginalTitle() {
        return originalTitle;
    }

    public Double getVoteAverage() {
        return voteAverage;
    }

    public int getMovieId() { return movieId; }

    public void setPosterPath(String posterPath) {
        this.posterPath = posterPath;
    }

    public void setOverview(String overview) {
        this.overview = overview;
    }

    public void setReleaseDate(String releaseDate) {
        this.releaseDate = releaseDate;
    }

    public void setOriginalTitle(String originalTitle) {
        this.originalTitle = originalTitle;
    }

    public void setVoteAverage(Double voteAverage) {
        this.voteAverage = voteAverage;
    }

    public void setMovieId(int movieId) {
        this.movieId = movieId;
    }

    public String getContent() { return content; }

    public void setContent(String content) { this.content = content; }

    public String getAuthor() { return author; }

    public void setAuthor(String author) { this.author = author; }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(movieId);
        dest.writeString(posterPath);
        dest.writeString(overview);
        dest.writeString(releaseDate);
        dest.writeString(originalTitle);
        dest.writeDouble(voteAverage);
        dest.writeString(author);
        dest.writeString(content);
    }

    private Movies(Parcel in) {
        this.movieId = in.readInt();
        this.posterPath = in.readString();
        this.overview = in.readString();
        this.releaseDate = in.readString();
        this.originalTitle = in.readString();
        this.voteAverage = in.readDouble();
        this.author = in.readString();
        this.content = in.readString();


    }

    public static final Parcelable.Creator CREATOR = new
            Parcelable.Creator<Movies>() {
                @Override
                public Movies createFromParcel(Parcel source) {
                    return new Movies(source);
                }

                public Movies[] newArray(int size) {
                    return new Movies[size];
                }
            };
}
