package com.example.android.quickflix.model;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;

/**
 * Created by brockrice on 11/12/17.
 */

public class TrailerResponse implements Serializable {

    @SerializedName("results")
    private final List<Trailers> results;

    public TrailerResponse(List<Trailers> results){
        this.results = results;
    }

    public List<Trailers> getResults(){
        return results;
    }

}
