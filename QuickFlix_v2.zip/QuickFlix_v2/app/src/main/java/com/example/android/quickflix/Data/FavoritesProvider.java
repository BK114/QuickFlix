package com.example.android.quickflix.Data;

import android.content.ContentProvider;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;
import android.widget.Toast;

/**
 * Created by brockrice on 11/14/17.
 */

public class FavoritesProvider extends ContentProvider {
    //Implement insert, delete etc... in this class
    private static final String LOG_TAG = FavoritesProvider.class.getSimpleName();
    private static final UriMatcher sUriMatcher = buildUriMatcher();
    private FavoritesDBHelper mOpenHelper;

    //integer codes for the UriMatcher
    private static final int FAVORITES = 100;
    private static final int FAVORITES_WITH_ID = 101;

    private static UriMatcher buildUriMatcher() {
        //We need to build a UriMathcher by adding specific code to return based on
        //a match. It is common to use NO_MATCH as the code in this case.
        final UriMatcher matcher = new UriMatcher(UriMatcher.NO_MATCH);
        final String authority = FavoritesContract.CONTENT_AUTHORITY;

        //each URI needs a matcher
        matcher.addURI(authority, FavoritesContract.FavoritesEntry.TABLE_FAVORITES, FAVORITES);
        matcher.addURI(authority, FavoritesContract.FavoritesEntry.TABLE_FAVORITES + "/#", FAVORITES_WITH_ID);

        return matcher;
    }

    @Override
    public boolean onCreate() {
        //initialize a FavoritesDbhelper on startup
        mOpenHelper = new FavoritesDBHelper(getContext());
        return true;
    }

    @Nullable
    @Override
    public String getType(@NonNull Uri uri) {
        final int match = sUriMatcher.match(uri);

        switch (match) {

            case FAVORITES: {
                return FavoritesContract.FavoritesEntry.CONTENT_DIR_TYPE;
            }
            case FAVORITES_WITH_ID: {
                return FavoritesContract.FavoritesEntry.CONTENT_ITEM_TYPE;
            }

            default: {
                throw new UnsupportedOperationException("Unknown uri: " + uri);
            }
        }
    }


    @Nullable
    @Override
    public Cursor query(@NonNull Uri uri, @Nullable String[] projection, @Nullable String selection, @Nullable String[] selectionArgs, @Nullable String sortOrder) {
        Cursor retCursor;

        switch (sUriMatcher.match(uri)) {
            //All favorites selected
            case FAVORITES: {
                retCursor = mOpenHelper.getReadableDatabase().query(
                        FavoritesContract.FavoritesEntry.TABLE_FAVORITES,
                        projection,
                        selection,
                        selectionArgs,
                        null,
                        null,
                        sortOrder);
                return retCursor;
            }
            //individual favorite based on id selected
            case FAVORITES_WITH_ID: {
                retCursor = mOpenHelper.getReadableDatabase().query(
                        FavoritesContract.FavoritesEntry.TABLE_FAVORITES,
                        projection,
                        FavoritesContract.FavoritesEntry.COLUMN_MOVIE_ID + " =? ",
                        new String[]{String.valueOf(ContentUris.parseId(uri))},
                        null,
                        null,
                        sortOrder);
                return retCursor;

            }
            default: {
                throw new UnsupportedOperationException("UnKnown uri: " + uri);
            }
        }
    }

    @Nullable
    @Override
    public Uri insert(@NonNull Uri uri, @Nullable ContentValues values) {
        //Get access to the favorites database to write data to it
        final SQLiteDatabase sqLiteDatabase = mOpenHelper.getWritableDatabase();
        //Write URI matching code ot id the match for the favorites entry
        Uri returnedUri; // URI to be returned
        switch (sUriMatcher.match(uri)) {

            case FAVORITES: {
                //insert new values into the db
                //Inserting values into the favorites table
                long id = sqLiteDatabase.insert(FavoritesContract.FavoritesEntry.TABLE_FAVORITES, null, values);
                if (id > 0) {
                    returnedUri = ContentUris.withAppendedId(FavoritesContract.FavoritesEntry.CONTENT_URI, id);
                } else {
                    throw new android.database.SQLException("Failed to insert row into " + uri);
                }
                break;
            }
            default: {
                throw new UnsupportedOperationException("Unkonwn Uri: " + uri);
            }
        }
        try {
            getContext().getContentResolver().notifyChange(uri, null);

        } catch (NullPointerException e) {
            Toast.makeText(getContext(), "Oops something went wrong", Toast.LENGTH_SHORT).show();
            Log.d(LOG_TAG, "getContentResolver: " + getContext());
        }
        return returnedUri;
    }

    @Override
    public int delete(@NonNull Uri uri, @Nullable String selection, @Nullable String[] selectionArgs) {
        final SQLiteDatabase sqLiteDatabase = mOpenHelper.getWritableDatabase();
        final int match = sUriMatcher.match(uri);
        int numDeleted;
        switch (match) {

            case FAVORITES: {
                numDeleted = sqLiteDatabase.delete(
                        FavoritesContract.FavoritesEntry.TABLE_FAVORITES, selection, selectionArgs);
                //reset id
                sqLiteDatabase.execSQL("DELETE FROM SQLITE_SEQUENCE WHERE NAME = '" +
                        FavoritesContract.FavoritesEntry.TABLE_FAVORITES + "'");
                break;
            }
            case FAVORITES_WITH_ID: {
                numDeleted = sqLiteDatabase.delete(
                        FavoritesContract.FavoritesEntry.TABLE_FAVORITES, FavoritesContract.FavoritesEntry._ID +
                                " = ?", new String[]{String.valueOf(ContentUris.parseId(uri))});
                //reset id
                sqLiteDatabase.execSQL("DELETE FROM SQLITE_SEQUENCE WHERE NAME = '" +
                        FavoritesContract.FavoritesEntry.TABLE_FAVORITES + "'");
                break;
            }
            default: {
                throw new UnsupportedOperationException("Unkonwn Uri: " + uri);
            }
        }
        try {
            getContext().getContentResolver().notifyChange(uri, null);
        } catch (NullPointerException e) {
            Toast.makeText(getContext(), "Oops something went wrong", Toast.LENGTH_SHORT).show();
            Log.d(LOG_TAG, "getContentResolver: " + getContext());
        }
        return numDeleted;
    }

    @Override
    public int update(@NonNull Uri uri, @Nullable ContentValues values, @Nullable String selection, @Nullable String[] selectionArgs) {
        return 0;
    }
}
