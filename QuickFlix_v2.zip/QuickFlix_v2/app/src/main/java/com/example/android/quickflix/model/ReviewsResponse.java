package com.example.android.quickflix.model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * Created by brockrice on 11/13/17.
 */

public class ReviewsResponse {


    @SerializedName("results")
    private final List<Reviews> results;


    public ReviewsResponse(List<Reviews> results){
        this.results = results;
    }

    public List<Reviews> getResults() {
        return results;
    }

}

