package com.example.android.quickflix.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.android.quickflix.R;
import com.example.android.quickflix.model.Reviews;

import java.util.List;


/**
 * Created by brockrice on 11/12/17.
 * This adapter will be used when the trailer button is clicked in order to
 * open a new activity to play the trialer
 */

public class ReviewAdapter extends RecyclerView.Adapter<ReviewAdapter.ReviewViewHolder> {

    private final List<Reviews> reviews;
    private final Context context;


    public ReviewAdapter(Context context, List<Reviews> reviews) {
        this.reviews = reviews;
        this.context = context;

    }

    @Override
    public ReviewViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.movie_reviews, parent, false);
        return new ReviewViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ReviewAdapter.ReviewViewHolder reviewViewHolder, int position) {
        reviewViewHolder.authorName.setText(reviews.get(position).getAuthor());
        reviewViewHolder.reviewsText.setText(reviews.get(position).getContent());



    }

    @Override
    public int getItemCount() {
        return reviews.size();
    }


    public class ReviewViewHolder extends RecyclerView.ViewHolder {

        public final TextView reviewsText;
        public final TextView authorName;


        public ReviewViewHolder(View itemView) {
            super(itemView);
            authorName = itemView.findViewById(R.id.tv_reviews_author);
            reviewsText = itemView.findViewById(R.id.tv_reviews_content);
            }
        }
    }
