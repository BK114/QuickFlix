package com.example.android.quickflix.Data;

import android.content.ContentResolver;
import android.net.Uri;
import android.provider.BaseColumns;

/**
 * Created by brockrice on 11/14/17.
 */

class FavoritesContract {

    // The authority, which is how your code knows which Content Provider to access
    public static final String CONTENT_AUTHORITY = "com.example.android.quickflix.Data.FavoritesContract.app";

    // The base content URI = "content://" + <authority>
    private static final Uri BASE_CONTENT_URI = Uri.parse("content://" + CONTENT_AUTHORITY);

    /* FavoritesEntry is an inner class that defines the contents of the task table */
    public static final class FavoritesEntry implements BaseColumns {

        //table name
        public static final String TABLE_FAVORITES = "favoritesMovies";
        // Since FavoritesEntry implements the interface "BaseColumns", it has an automatically produced
        // "_ID" column
        public static final String _ID = "_id";
        public static final String COLUMN_MOVIE_ID = "movie_id";
        public static final String COLUMN_TITLE = "title";
        public static final String COLUMN_USER_RATING = "user_rating";
        public static final String COLUMN_POSTER_PATH = "poster_path";
        public static final String COLUMN_OVERVIEW = "overview";
        public static final String COLUMN_RELEASE_DATE = "release_date";
        public static final String COLUMN_AUTHOR = "author";
        public static final String COLUMN_CONTENT = "content";


        // Create content URI = base content URI + path
        public static final Uri CONTENT_URI =
                BASE_CONTENT_URI.buildUpon().appendPath(TABLE_FAVORITES).build();

        //create a cursor of base type dir for multiple entries
        public static final String CONTENT_DIR_TYPE =
                ContentResolver.CURSOR_DIR_BASE_TYPE + "/" + CONTENT_AUTHORITY + "/" + TABLE_FAVORITES;
        //create a cursor of base type for a single entry
        public static final String CONTENT_ITEM_TYPE =
                ContentResolver.CURSOR_ITEM_BASE_TYPE + "/" + CONTENT_AUTHORITY + "/" + TABLE_FAVORITES + "/#";

    }
}
