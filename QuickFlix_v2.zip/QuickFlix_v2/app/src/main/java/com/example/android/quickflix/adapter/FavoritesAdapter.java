//package com.example.android.quickflix.adapter;
//
//import android.content.Context;
//import android.database.Cursor;
//import android.support.v4.widget.CursorAdapter;
//import android.support.v7.widget.RecyclerView;
//import android.util.Log;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.ImageView;
//
//import com.example.android.quickflix.Data.FavoritesContract;
//import com.example.android.quickflix.R;
//import com.example.android.quickflix.model.Movies;
//
//import java.util.List;
//
///**
// * Created by brockrice on 11/15/17.
// */
//
//public class FavoritesAdapter extends RecyclerView.Adapter<FavoritesAdapter.ViewHolder>{
//
//    private static final String LOG_TAG = FavoritesAdapter.class.getSimpleName();
//    private Context mContext;
//    private static int sLoaderID;
//
//
//    public static class ViewHolder {
//
//        public final ImageView movieImage;
//
//        public ViewHolder(View view) {
//            movieImage = (ImageView) view.findViewById(R.id.movie_image);
//
//        }
//
//    }
//
//    public FavoritesAdapter(Context context, Cursor cursor, int flags, int loaderID) {
//        super(context, cursor, flags);
//        Log.d(LOG_TAG, "FavoritesAdaper");
//        mContext = context;
//        sLoaderID = loaderID;
//    }
//
//    @Override
//    public View newView(Context context, Cursor cursor, ViewGroup parent){
//        int layoutId = R.layout.movie_poster_item;
//
//        Log.d(LOG_TAG, "In new View");
//
//        View view = LayoutInflater.from(context).inflate(layoutId, parent, false);
//        ViewHolder viewHolder = new ViewHolder(view);
//        view.setTag(viewHolder);
//
//        return view;
//    }
//
//    @Override
//    public void bindView(View view, Context context, Cursor cursor){
//
//        ViewHolder viewHolder = (ViewHolder) view.getTag();
//
//        Log.d(LOG_TAG, "In bind View");
//
//        int imageIndex = cursor.getColumnIndex(FavoritesContract.FavoritesEntry.COLUMN_POSTER_PATH);
//        int image = cursor.getInt(imageIndex);
//        Log.i(LOG_TAG, "Image reference extracted: " + image);
//
//        viewHolder.movieImage.setImageResource(image);
//
//        @Override
//        public void onClick(View v) {
//            //  COMPLETED (13) Instead of passing the String from the data array, use the weatherSummary text!
//            String weatherForDay = weatherSummary.getText().toString();
//            mClickHandler.onClick(weatherForDay);
//        }
//    }
//
//}
