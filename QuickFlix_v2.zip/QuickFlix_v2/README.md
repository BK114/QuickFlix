# QuickFlix

You will need to obtain an API_KEY in order to run this project. You can obtain it at:

https://www.themoviedb.org

